"""Orbit Wars v20.0 (0513) — thin entry: registry hooks + orbit_submit package."""

from __future__ import annotations

import time
from typing import Tuple

import orbit_submit.registry as registry
from orbit_submit.constants import HORIZON_TURNS, SUN_PATH_MARGIN, SUN_RADIUS, SUN_X, SUN_Y
from orbit_submit.entities import Planet
from orbit_submit.game_state import GameState
from orbit_submit.kinematics import (
    capture_need,
    is_sun_belt_planet,
    my_inbound_ships_to,
    point_segment_distance,
    target_state_at,
)
from orbit_submit.regional import RegionalGraph
from orbit_submit.scoring_early import enemy_eta_power
from orbit_submit.scoring_shared import (
    approach_bonus,
    orbit_arc_strategic_score,
    recapture_bonus,
)
from orbit_submit.snapshot import Snapshot


_NEURAL_WEIGHTS_B64 = "k05VTVBZAQB2AHsnZGVzY3InOiAnfE8nLCAnZm9ydHJhbl9vcmRlcic6IEZhbHNlLCAnc2hhcGUnOiAoKSwgfSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAqABJWTMQAAAAAAAIwWbnVtcHkuX2NvcmUubXVsdGlhcnJheZSMDF9yZWNvbnN0cnVjdJSTlIwFbnVtcHmUjAduZGFycmF5lJOUSwCFlEMBYpSHlFKUKEsBKWgDjAVkdHlwZZSTlIwCTziUiYiHlFKUKEsDjAF8lE5OTkr/////Sv////9LP3SUYoldlH2UKIwCVzGUaAJoBUsAhZRoB4eUUpQoSwFLQEsOhpRoC4wCZjSUiYiHlFKUKEsDjAE8lE5OTkr/////Sv////9LAHSUYolCAA4AAP/RfT7DfT0+Zjl3voIVRr7Tyc09gFlMvU28Q76d4bY9DY6AvajSpz0rgXM+COLiPXY3YT7b8kM+6CiaPQcjAzwxGGu+F/tfvR6DcD6c7j29GTnFvRhrFj61vzU+I5dAPrfiLr7WN4C+oVgrvclVKj6dFuC9fXFFvi1k4T260XG+Cw4TPn+prz2GwXI+u8g4PQXpUD7c9NU9u71LPnqsrz17hRO9O2xmPXKQUD47gNm9c28VvgPVrLz8KLE9ulNRPtr9jT2vxUA9CxNSvhSdHL6S5Oq8pBT6PETHOz6hjYC9oMdOPgvnFz38oEI+8bUCvfprDz6rZzI+MQQ1PWtX+T0zvVC+HT6KvmFvHD6KaAk+Uej2PSHaU76yvxK+dUAFPtYCA74Wo0M+C80bPZMeqL26wCk9cCkHvDUgXL576/s9KmsZPvrZqTwlxnU9ofiVPeZWmD3Y2ue9v2omPJEP6T3r2Ws+hBmavYAnAr5CBoy+BUcXvplm3L0xPFq+LaxaPjIIKDyW5he+2/r6PWLtQz60pmA93P0CviwevD38/aC9+mE9PR+1Dj44zos9k7EVPV6gij4ZAk4+kv/cvV+vOj5vQGi+nkbBvbqDUb4rAAm+HgQdvuVRDz4TgCy+LViLPvKhgTwyxWU+mqplvUSOJL4RViW++NUEPqYXlL2RTD297FftvSO4jb72a0a9aOh2vnMybD5x3yM+PIqZvbT1GT7TgFk9sf9ovka7ub3KfH++e1uFvtvDtj2H9Do+qDP0usMMgr5BXFw+6iuBPj/mFT7i7as8aFV2vnNdZb40zYm9VCPTPbTQgb79dis+I/+fPM4albycz4Y+brLOPEMDXb5EW+C7AxalPWVrMz5GVKO9o2EbPjmpMb40yyg88ReCvcRkcj6aBpy9uut9vgGR17yp76Y8J+WUvGujBL5tHa28+DRUvrJfED4RM+E974YHPiIq3L2hYe682rpzvmbFXL75vHC+AgmxvdNFKj50SQY+zaqFPjye+zvmvdu9DbPZvLAnI71xYom86Cp5vqynmD2KgLM6z1Irvif7jj3Nbxw8VTI8PX89wz1Lv1a+hrbXvfso1Dw/rI0+Wt02PsQwR740I/C9RsxZvsE+Jz5/FoG8ecQIvuXuhz5iVCq+sGyNPic4f752m6E9E6R8PekkcT5dx3c+6hUovu3i8r3SlPK7yL3BvZoAdT7dtK09RDeFO9HPhL2UwpE9eGgYPnh/fD6P81g8ZhVBPBV9Sr7Jwpu88hgFPud5Sb59t3++HQ8/vk5KND4IyhG+4G8bvoPAtz20H1U+Me4PPmJXSb5LK32+HiSFPqJLkL2l6gA93OMfvuB8B768EHm8XuM+Psb9hD6TwhK9K/V6vldK3b2gFXq9q08uPn8KPD0JO1q+9nnKPEKNSL6Zsuo8VMEBvsFUgz6YVSQ+4t9yPityOr5Ud1y+sd7+PciOsjt8yfU8wFdWPpqaaT5ieP296kxePgx8vL2YZcS9LModPqAR+D31HLS9S8JLPjfNBr7TIYc8n7dXvgwLZj62Oje+enNUvbmvA76OGno+QyZiPnp3dr0cskc+9auDPZ2N5z0dt0C9EgmBPgfTKD127XO+6M0PPinuYr2RPU2+e88HPntJfb3tai6+GvbhvJ/M0r2rUwA+IjSlPf9N1jz9E8I9uHJQPHRJXz6KatK9VK3UO+khHD2kVpY9JkPyPdQKgr7U0hQ998zsPRyvPL4IRB6+wmK4vXmIUL5R3xO+JZtePuQyZT1Koy8+w66ZvPWlQT6JrgE+Q7opunDPLL2dBEE+bGJIvpqjIT4Z/Wi+NjdAPv6yv7spKG0+ZS46vhepHz7bRCo+tfXfvWa7ELwuZ1Y+TOxtvsmskb1suF6+tRtAvgnw1T1Lp8m94tWVO1zutL12h4K8QPEkvqaa9b2TqWW+wTaMvliBWr44ANE8rU1cvi4F+r11Y1g+nQOnPZYeID685ik+Dp7cvRz3A76833m8mRVQPrLNjT4TExi+rwZZvhTOf75Hn4O9Fn8/vuBp270EFSQ9nyU9vuCUSD4YQMK9w8ApPgRCRzvmMjk+82CBvNDDbb7jlqQ9o4GnPXdxMz4iOm0+Ueg8PoOlvDtT4l2+4lBBvuc8HL7Gdq29MOa5PfIMLL11l3W9WhGTvXUqer5qd0O9zDP2PevKDj4+yTq95HilPVWhgj6eMTm9RPH6PfGdHbzAKi29gG+2vXBQC76NGaA9ZTdaPm1HBT7VRZQ7KbvkvX6DfTxD2Tc+1C8gPit8Dz4HYXU+4kSjvR+dCr4ofU6+NOkSPoYZ/T1bdq09o4WzPWLdaL5heI49M708vqTekz3GIUe+u/gjuz5p9b0rgTQ+b6e0O0AInbwcWG4+1KUUvrVdxr3mVge+5kqKvVXQgD7m9EU9iPLUPX5U8z0o4ho+/UOUPQy4dz3GRka+DqMHvmRgFr5yfd88CYRhPh/VaL2PLzm99EjlPa+sqrs/pEO+u80ZPcT1u73HDOs8nwvBPUiU9r2WpCk+P24RPNDYHb5ubwm+H4r3vDcjwrwxf1M+j181PK8TdL6xKr+9KYRRPnFqQr47MI099stfPhNHG74ORuQ9XhB0Pt13Kb6N5sU9FdkmPWtPk71qY506LJ4Gvn72xT15+329uEnGPd/pU77Txzw+ApNLvmEgeb4L6hE9ly9qPmlS9T0Lq/k9zEg0vlQTPr4+GW29eawZvoDtb74pjhE+SnduvTNCa72doQE+U3l1PiUuRz3rtw8+jlD4PL+onz2SKCi9YkYYPlK8GT6NH2O+7yd6vhbDQT6dZoc9SEAxvf6kDz7yAqa9tURavBYZaT4nmHQ+XkQ4u2HZIz7vEeA9DKdoPXcHv7wLkQk+jY14Ph7SQb4Mxu49/sxCPTPlYT7zARu+kw0zPaeK9z07Qz8+nX5nvnSHyj29fxG+whKvPZf5dz6Kw1e+maaRPWupdT2mD3a+KqOIPuL7h72P/Vy9Hk6EvgXIHj57coy+oxQyvQXzZL3tpYO+iB29O3d0kL29F3s+MBZGvUKMYz4HcLa9QsITPVO5Vz5hUam9ZmeBPpqwxr3VLdI9SlKdPSpdQD4eebw93fEcvr1odL6YdVe+2LxsvsZNDz4CZFq+XcgSPt/o4Ty9azo+P6WJvq5iQD0R3/s9H7NmPqwKj74/YS0++xK9PWE2Fz6oQmU77O4tviHIEj5Jf3A+RgaPvS+7ML5duEy+mIcovBl1vr25cRi+5zunPEweVb5kS3S+ypx8vuN34j2Dw3A+D4VCvndnGb1VPUE+ujEevXsjCL5BSCG9O9AnvkcAlj4O6C8+atlBvKETAj7uU609SzzfPZ6AY76a+Yg+eAAkPfeIAz7D2xu9Nl6JvJVxszqoLCU+9Q5rPnM/jL45he+60WZmvvI7X73xS5K+NT9evvUM0D2dVk498S/CPQ9HdT4q5Ma9BucLvpv95T1A9bA9br+lPYhUX75RGQm+NK+muxfpSL7f1ko+nISnvVgafL77TTc+QARdPH2KL76fijC+u3nsPZFkhz5QbPm8aQObuzbvZ76OyTa+9yqwu3XXhT5bgbu7yAD0PeOlMj4vw1U+nZC5Pap5Wz5tVga+PmRZPi7qbz6AjaM9ezdAvMmH9DqLFj8+jD3lPdd5Hj52Hmc+dogFOaO3pT3Ha3G+xc8bvttoSb7yxqA9C7CGPt3e3r3TxjU+PBnZvR4eWD4/9pY9okOZvasXez6bRx28n2UavBrXkr0f1dk93R9avi5hQr5SThy9IGayvYAsaL4puf49b89NPpeglL3xd2U+V883Pmf4I71om2896UcDPao6Lz7i4S2+bVTzPU3CETySMWO+4j0cvpVi97wczRm+lh8wPb7baT4MzC086kDIvDH1hT1RI+y9AjJXvr6U0L3rkDk9fsMevuNnWr0Md6m8iBN0viz+Az4leoY+xofIvbTBFz4y8Hk+d90PvRnV5D017zK+oyN7PpKuJ71njM49pREfviSOXj7CDpG9OvZTvvewp7wm2VO+RHf7Pb9PAz4VWTS+x6OZup6geb7SS2U+KxoqPuCdJDmzmbq93cZju5ikOj4ZaV08L5Y+vv3p/D0Rr5y9FWl6PnIH5LxrXVk+Ys++PXFrNb3qsoa+b7OLvCzzTrvK7J49pxtbPrlH4r2VkIq9a63TvXP/kT3wyGK+K4XkPJCBcj4gJSU99fgLPovaGD417Fq9qUlqvmMUL7ybtnk+Qnznvd0UYTn32lu+l3o1PYBpGD2NHoE9RO9kvjecfr4143k+4hSCPa7GFr63tGm+wp5IvqpY0rx492G+qwSDvSddML6oJtS9sguCPYJfVr7oCXa+saFpvQFy0r2ilzm9n0EPPoypgj44BIa+tl2Hvkr0S7wCCqS9XLZOPltDd70Wn4k+iEITPkWt0rdC6we+Ec4jvQkptL0eSD4+zzuNvZRJCL7Wu5I91UZevBsIRD6UGIk+QCdovbyETL5G5S89XWF8PifGIz6af2C9TghAPhFnTb7jak082U2Kvk8fITwq3Rq+y/2iPIF6Qr05/9S9mz8lPl85hr2N0oc+WwzOvKKXKL5A+hE9DIYqvq/MwDyLtAK+kjAKPdV8Zr3EgIS+SP0KPnmafT5r9tU8BugevtVEb70ebgI9fnCSPo21Wz3nSWS+wuYiPrH4IT1v3AS9e8YzveWTaL5jT2c+1YAQPtegKT6J3Qi9CatFPoLLcT6FlDY+XSkKvh6iBr65WjU+6GY8Pp0oG73dHn6+b7MIPjsper2rWiE+lHSUYowCYjGUaAJoBUsAhZRoB4eUUpQoSwFLQIWUaBqJQgABAADrD1g+tjQ3PmAljL34Ene+laGKvZdYGz2SK3M9BO79PahLAr4JXga+ssQxPQsw2j2l/Xg+nqKIvh+sGj4Lrwo+d+ycOjYYiT6oqSo+NAI2vrIqY76ohmI+6F4fPg7B/70awYw+T415PrChwL1IdPK8N8B+PtRWnT1wa2s+dWI7vgOEXT4GTTQ+OiNsvRPJTz474ZS89NRAvql6fz4JqkG9SBehPc9YQr4rz2g+k49APn0kYr7USmG+zRw1PgAh971Ifio+riGYvFaePj4qEp68iF9ZvrCDTT5BX3C+DyMTPjqd+r1xk0i+nYfcvfBpKL7BkOO8WpEFviwwgD3OBS++lHSUYowCVzKUaAJoBUsAhZRoB4eUUpQoSwFLIEtAhpRoGolCACAAAFLogz3tUGA9293hvS+4s71UuJO9Dj8HvXgA/DxqpQM+AFbZvKVvmr1fLUO8tFkBvZMnxz1wt249FgSiPZlzmD1NYog9QEdcPWHuOr2vs8a9OiFPPHMWAT4HJCw9twkAPoNZ3b0pHoy9vA/1PYDN/DsfARy99BCIPSEsoT1jDfw50ZrBO9vvmz35LGs92syhPSjIED7iSrk9Q87ovabIlz37US09oE3VvXO/5ztaebs95c7KvfuZf70PAsm8c97HPUGaG71R/D89qU3TveUcujwwVFk8GSC7PaI5gb2DLc89yE1vPZhgkLyQ8uK8g4b8PEoJSj2SKnk7He3cu/p0tD2cM8I9STiHPcYOGz2uj9C9buSLPDmbnryFJZs9LgwTPJyRw7yM9pQ91yEzvPnMhLwq0c681PPavcPMG72P49w7PQbavdYRWz2mjkW9+IHlvXTZbjz94nq9YCqHvd3w4bzbDPI9DTBVPVUhcT1M6h49qiW/u+r9qzyAFko9IBYlvRMUjb0b94y8UFXQvPwbNj1iqtO9AIwhuXv/MT0aUAq+fwnBvTlCA77cTwE+RBuGvVtdcj0YsDu9ysNpPU05RLz6crq8bWKNPcVV3z33w5a73NMnPdWLtT1zwKG9eWFfvEZzjz0AoIW4tPVCPVhndb3Ub9Y9X3oKPV8fhj1lZag9ZfWnvQskAr6MzHe9cSCPPXjtij29Uje959Q3PRUFhzsw0r891FS/PaMQlLwiZYo93IOAvbhNzz0vTK+9qt34vaq2Rz37oAC+YusGvibpkzzYD6o9VUiOPb8nljyHsv29COUKvslKwr2NQ5m98EAyvbme/L2IPyI9t1fYPONX0T0i3HM9sBbZPeMNmD1pKXc7QNh2PZSJwr1vlSq9XOkmPd3a773fKf+9RLa9PfcMsj3k+p69GqqXPE8GEj1Zi0i9CAjyvTtjKT22ABm95XBBPbCkOz3ybxg9kiXSPcA3m71F5KI9wPUWPYh43z38m+m9IvagvNwP3r3Xp4c8iXhfPUpPmL2Crvq9jsK/vf+AC76isp09XyWAPe/dSrzoI9A7EBQTPD5d9b27Gvu9XQ3evaNthz0K4d29E0bhvcUOyL1Mopq98dW7PDCUFb08sDq9uAprPQQimb3O/YS8IMrTO9B+Bb4K3vS9uubaPBzxIT0dpLm9/uZnPRrWbLxu7AY7D3dQPJyMtL0sGYY9ffjYPNFlGj3QwG09NsKmPbLGyj1c7ai9Bl4BvhJjJ7zk5L09fEIEPqc1nT3QTtG9RtmIvFV9dj3Dibk9vQZfvXGjzT3oF7y817yWPWqqozy0m1q9/Y3fPMhuyr2AiD47/CjPvVX+LL0Lbg69Aa4BPkdFvD2YXPe8GA5zvawrZT1IZVy9hi/LvaC79r3qSZM9huPpPXCg57wSecM9IGAgvQC8Ujmk2Gu9NKgGPfjv1r22Xt+9hEdUveAD7LxgaC89AEZjPICKhz1ISfe9IC0TvMwCAb0UE6c9KGhjvfzhqL22prY9NE/0PcgqJL3kPQq9AAfpO+zzaD0oLks9UHqhvDSm7j1kn5o99Gi1veDYvbwYx7C9jHdivagiYL0ad5O9wBucO6DpLrzm7OU9YIWhPH716j3oNss9kGFUPaDU+jxoACQ9tEqWPcwqbj2gM5I91Iw1vXgP2zxgSac8TPLBvbCtQ70Aot+79GeUvejGx71A/nc7CzBgPQmvDb377O69W8utvTOEz70TQOq9vvAvvUDQa72DOyG87q5IvZaymD2EPI69rATyvRDusD0nNFK94dFuPfrRJ7yLXUi8NL/0vXWpeT1tvDM9OjaoPVN/HT3VOJG8AY3Tu48grj3xRJa9vA0evXw7wrykMCO8MobGu+x+Oz08kvS93WMwPfhwiD12L5Y9HaMhPMjAuzyDiiw8QhK3vetDmT35DZs9GH5fPQ8PRT0VNAG+fHqgvYgKwzz9+IY8rMuPvBYxbT11OIM9KdalvfSQ/b3tXYy8xzS0PSMAPD1Ewlu8gLMuO8BJmTwAD1a9jtvhvYtYHTw2DrK9M+HbPU9Lg7wxAJ89JNv3OeLc7LutpsE9Um+fPSpZfjxhyIq6JOMuvV4Nzz0FArq9FW+0vdLrYryO7LO9hwL4vfes6z02iwa9XGu8PH5epD37Ydu8JGPBPW/fDT6Ms669Wyq6vK0Hub2HCOQ7KnlCvVR2HL3ph/68k01yvepBcb2GZ1+95BvHvdZYAD6M3z89lzrvvQv5iTzqMc69b0EEPkk9WL3Biz29tpW/vc6l9z1EMve831UfvGdI5L3ogdi8p8WtvUXDnD0hP4k86AJMvQ0j0z2u7pM9ecOWPTrhwD0AMAE+5zkOvaibfr3ILOG961fQvRuySb2+LbY9j1cBvlhsADxZH1S92SfsPNhgkD2705c9j0WevbNKhDsLQaE7biCxPYMxsz1TWLm9TD4NPELZbz2LHtc99nTmPXKBU71MUMM8ACyVvAjG9r0MkGI9VYbSvBfG2r1XSUe81H+kPDUBJD0uSzu93HC3vQD8Xz0gK3S8eLncPJqotL22mjM9XwKLPX9q6z0qziC9Fq68Pfmk6z2t4ZQ94DcfPIFxqLtlYbS8jH5xPHC/1z0rB+A9elo2vYfkIj1ehNO8Fr5/uxXBorv5w9A85yLPPeETgL2YH9E9+HEIvaVvzDxnDMa9fLgZPWavTL0QrWa8JJn+PZR/iL3tWNG8y1bGPJZ6Fj2JVIC94JUGvvsJ5r2cVdU98BXIvF2ofb1ROnI8Mw85vWyC6z0GGhY9GxmBPMj8rT1J47686cLsvDC3IDzpJjU43TP5uyqstr3yRCK9QzrpvUcAJT0zFYo8leTQPS1YtrwSmJk90ltcPT17xD0x6x69gLA6PbqpsL3/7Ba9IuBBvf2ZVTxuE5S8jWe2vaiQ3j2GJs89tzq8PJSbnz2pkCI9507CvFF30j1rQ+E9FmCnvZ9Jtb07w4E9Hqq6veIsKb3FKm68STJZvQ8UO7w+HSA9sxJ4PaoCjb06ny68jQkovVbevj3czte9ABsKOgD8PLxChta8dTh1PTA3qT2MeLi9TLmIvUtT+r0Y1ra9MX66Pe8dmr1izmW9mL5HvU01nD2RqAW+b2n9vXmbMT0mb9497/XdvSqztL1UIQO90XqhPIeVf70J5I29rmMOPbeAqj1hILc8VPTrvQlKrr3KS9a9Sqq3veDTnj3bbB68fH7SvIao6b0+I+u9Jm/MvDCvvj0mipm9CA4Lvl2RUTs3n0u9YHGlvf0MVT24hbG9BcKOvaBzkr0QAPo8PqfoPSvkUz0BHom9MrPwvdh0lD3wc/29gDQ4vQIsjz0/e8u9S3eePfP2wLzM3pe92wbSPLOdAT1Qlaw98Ha1vKT5l73uluU9U3ykPQTwlT2NTpg8DwxIvOxMLD33NtG9u8OZvT5JLrpryum91sbOu1H0pDvAjsO81ymVPPXwajyTqBQ83d9qvcwOtD3Z4aO8QDcAO+Zrtz1C+1A7z0/mvMEz/D2B+sm9nYaUPAsaTT3K6sQ9PoTtu2rhq72jZuw9SYr8vLxnzT2ItDS9ymcCvqCNgb0msQi9NFPYPZV0Rr0y0XI9aVMyPTb8Oz3bvG29AKZkO4v4ez3WeGG93CebPe9bZT16Cdw8SadfPK7diLyGQIc90t3HvSJJDz1LO/a9S4ZmPbeKGD0dn8S9kPzQPDRrtzw+2508pQR8PWYcsT3+Kpy9UCzsve1M87265Em9+HLnPVcmQD2t4HK87LPKveDYX73LWi6+eBoPvNz33D3YS5Q9FyM3PUSk0byCJBy9ZIfUPYEVxbxrqN27rya1vOrAjz2NIDG7iQPDvb1klj2dysa9xC5RPSbe9L21F+u955uIO9zh1jxnDDm9aBZJvTTSnD0DRz497PPGvUEFxT0QuJs9wOQFPgpQcL0ldtm9vK8IPMIEubzfIeG85MXtPVpnhz3dXGE9VP5DvYhLzz1mCo49KYoTPbVEzj1zQZU9qQfvPXrtqj2J19+8RjbAu9ip+Lsxa1M9tMJ4vVjQ+j3ngt89wvd0vas9yr2nyWO9JGSsPQ4Nu70fZRS8F16MvRlAqT2OoUg8CEzNPbmzrTyCl0w9FXdRPStoCT3qkqC9jRd3vfFogbxUeUM9QhbjvWgawDxPw4Y9OxuRvVcqfD2gkpy8DLvovRXLE7tg5d69lfxaPZnk1jwOpes9ApuvPS4+Yj3/oMK9qlfIPVX17b0AS/y9m4uiPQDKtbsqV6O8A/G6u7Mn1D1HOjA7XrsCvpX2hjwNMvi91tC/vf0ZhL2wUR09PwzfPPgJkr2ZT0s9c8qWvV9RqD2XAqC9W3u9PR231bnm7r88/pYWPcNKBb15kDA8P1AyvU21nDyQ/Uw8GB2DPcp8QLy7R6K9U3jFPRr5k70KS7W9Xn8YPcQWuD30WMo9CKFNvDr0Cr6iIuS9meiSvSF8/TwaWJ08P7ufPaMZg71shpU8t+G7PZmy1b3zw6S931jGPV2n+z0PxFI9BoqavRs2+L2OuwG6Laq0PU6Bt708u2I98kqMu4J/eruI/fg92rmJPbMkezxeETm9e3MavQ92UT04K/y93Iq6vTJ6Br2A2+S9KMQ/vasvqbzLibk87mhaPXZcMLvqQLk9bHw4PWKYxL1wGqQ9PL70vOTg57o6mRE9iGjgvdXAxb3SANK8FOLmPahSpz3xbdQ9YGuOvZfrBD0XH8o8iP7xPUAf0r3ngdG9R6vwvZTegT2K1Pu9RJIKPU3PKTzpb3Y9fzVzPa0Vmj2tV7M8mmKgvTfm5j2codU9b4NePOGuzb17VvI9L6DbvNlGd73bqPw9TWvkO2FoGjyklQG+IiEGPejT0jyTS8M9RBfRvZIW4D1+6PK9TkfnvQAdd7wT0LG9Wy6IPZ+BHD07uMa9m8GUPemACD7y53g9JALAvQVNUzxDjIW9xG0cPaA+YT07D8G9+T7vPAZ00b1+HZc9JEO7vdaDjL24FBY7N4kSPVCv5L3FI8+9WNr2vWAHYz3P64C91KnyPL2G/73GMD49qjUDvjzVF71Euo69lTWnPThUo720Qgk9ebsjvZx4zb2WaMu9puHcPXb4sb1vDYq9qmjgPUGkrL2KdgU++7LIPd1O1T15dxg9NjEivoy7sz23tz68QtmmvHuWFT54CL49apWvu/+/oz2vZn27fLq4vK2g3T3WdcC9cRRYPZU11z1wU8K99t7HvIp2f73u3hm81B8MvE42Bj5Jfsy9Jy0LvdHujL0KRoM9Iq4tPUg3Db3jG+E7PQmwvdxMBz0z67i9IP8gPRFENjuqOIC6q0F0PYh99z2w6mi81LCAvBNlerspjng9cZKgPF2v2T3iLFA8UmIovQs0lTz44Mo9mj7RPY1RizxlaLQ9DVusvebTxb3wmZy8hfSRPU2Joj0uv1S9uwHtO4w2Db1oYa+9H4xmPPgwZT3kfjy92IDvvIgJuj0r48q9+gZ7PTta1z0wocY9uJ2bvWMkYb2EEVQ9VPwGvpuJLDxJK4W95cF8vFTuNTy3WAW+VEvRvb+vNTxYc809QZfAvSFgtj1R2/G99GWJvV/mTz3yBGc8BDzaPUuhyj3ncs83RYJPPf4HVj14gyQ9XuixvBRTBr2ebHS8avPavTTwU7vdbqS8en9evSUm6D0QPSU88GRWvZkWnD3VO7K9k4XyPGTrn73MZ049M2QCPX/+3bx7lDq9XfS1vMtY4j0eDZs8rbr7PB0zvT0IZLQ9KJW/vZGqnD11JIS92KLdPeUwWb0QQIC8/kCkvbok0buP23O9k56SPVJP4D0ozxS6T/SdO2YZED6JWrY88h6SPfRg1D3obuy6hs8KvqjRMj2uu429F2oGPlNnvL1CeGK9WgmfO8C7BTuVWMc9Ts7WPVoHX73UACE9XikgPQkAhz3Sr68956h/Pfd7Grzm+vQ9JNV6OLmCRrv0AWg8XCnBvd25iL2Xrpg9+uchvVJvVr2Hp4a9LztRPV/I2L0msTk92ym4vUCiKr14JIi8cByDvBuLtzw+5sE8uBQdvTnidj03OAg+fFi5vQiKzj1MHdO8la4JPbdE5Tz8kVI8+0WgPWCahLtRpUI924vEvSSyYDw3hLS9+E6IvNDAOb0uxwG9sXtkvBPHMT0yxtW9Wo/BPZzow72VoaE9aR66vM/jij0FW+M9FeRgPeW9ELwC6J299vDNvOUgDT3RCNa9SmsCvkIl5T04z6G9G1LQPT9Nnj0ksoY9KLuAvewYKT22Q269Dd4gPcNSUz3CgqI9WLAEvrn3Zr3Re+U9K38pvQDmAjrCQtw95PqiPKgKJD2yBjw9b0XKvb5q2j26Ajy9jNmNPcf7nL1QpE29wWYKvqwhWTzgPjW9gdh7PY5JJTsLNKk9C0G3uwfdJ7uqlZG7kyqtPSgS37vFPSO9JyLcvSR2TDvc3CS9pJCyPezmGT2CEYm94A5EPXpX9z3YlN28SbWIPc4rVz1MU7w9QQoMPjY00r34iqO9eBqEvQUrKz6B5P07FKXIPFT0CT0GPR49cttIvfjhfz2Bkuc926h7PPDarT3u57U9SjGBPf2J1j32UxE9fPKzPIgGhT0n/7O7QASrvaNRRr1boiE8G4XcPYGerz22Cqw8B4S+vdsYy71cbL49gtelu/G9+z3HObq9QTTbPYSHxD3vvp49lvSdPXwxyD23Q4S8XhmHvX5egL1rCYm9cY7GPLCyUT3IpOe9HBDgvbZJLL1fyaW9yuSrOrwT0j2CKQc99eulvc+skb2GXxG9AKhIOmf9uj2WzQQ+g6EIvgAeHD2gJzq8/tvAPRWT+L3MRmS9meygvQoL9z3cR5Y9fSzzvEf8Ez2LbKo71DXhPeSeaj1vmt07eeEtvbhFlD2eSQ++gNZgPYZejT1qkTe8AvqovaYxt70q+OU8/ClgvaYxWTxs0Ig8RCpePC1a6b3pXY+9E9vSvV+z3T04yeG83cjQPWaKvrsVZFK90DlePLh2DTripa29yMi4PHBmCz4Gb9c9ak6kPA2rBj6XlOo9L9IxPWKWxT1S+K694GqQPUwjnLwCaL09vz/gPa8aFz0Kn7I94xvRPI9zs72dzmY7pXk9OntehTzj3JC7Thj2PLTL3T2uNlG920NivS1pkrzJzvQ9AMBvPRhgXj3F2cM9LcuIvQ6+QLygQ9u8a3HdPfrDT7wr10g9GBMsPkrD+r1HM1M9Sl3APRyJtz3zUW67axlUvIt1Sj3AgYW8PeSjPG195r3mx869YjXgvOESczyfrDY9BpVUvZa7oD3sswY9QmIrvcQc8j3vAei9HIiePFSdqD37uaY9u//VvMzH/L09itm8uCacvU9Eyr3U89u8NksHPWJcob0g5Za8Zbs1Pcom1L3ivf89c0utva1uFD1VJoe9KM5WPQyVf73qp6m9K6GSvUm2ubyAiay92+vbvWdD1z0QUKW9qIJivdgtSj0Ky+K90mh3vXkN+j2tWz49fVPxPWLQ4b1gUx690HmAvazUpDwyn+A8659dPdSe+L1WLps9eGX3PDBbvj0Ag228qIiDvY6/rb0Gfdk9DJshPejZLj2gkym9CK3oPYKq8z3QlM+98JAJPKB5+Lz+2ZG9THKuvazJH72abby9ijfNvQgNtb00D/Y96Hc6PeSsLT2Q/mo9JIs+vV5shL0SZoO9hrTBvciQwr0ghlG8eAliveKOnj06euW9UIDnvK7Y6r2Sjsy9YFOovcz5471uxYk97h7sPQQgsD2MQLG90AWoPCBTyz1iUNy9CPQOPdQu+b1cJV69jAc8vZxtsT2WP4C9nl/NPSAhh7zMHmk9oLWpvHhN873yh4m9FN3+vWxhU70oLXY9kJljvRoh+r1ga447FBpavfj0Aj3sLo898AXYveZf2b0Qfb89CGXsvADiubmyGIy9TE7APXARc7wo3Ka9Ep+BvWxmtz0Ijzo9PIsQvRiFJL3gEe27gOziukCdzLssoM49GrCrPc75o72gFaI76LT5vRQnGT1ksk49gFzkO0Q3I71gQee7MAEyvSgvhb3A+GG83rvqPVD+0b1U5Ta9gnfuvapZ8r2w/+q80EnsvRCog7zswR+9mI96vexfBb2m/+09qKKkPVAYljwmmoo9CBeivLBwrb3Etp29Gp+dPRBGC7xUxGI9uNOtvLDgt7zmpNy9qAn8Peh/973Khdk9zn6/vdRrnT326OK9tJNLPa3lr7xYjlA7ejuhvS27i70EQra9nYudPBLyhD1kSHK91SuhvXgG772vuM+9o6PfPbHUXTzEVXi9Ah7evdw8VTxLxOm9ANqIvaAvxrzSs4i9uuOkPYN0Rr2Bj8M9HZbYPdpeBjzD4oS9PZL9PbgN3jwWmcQ9KQDDPR2AJrzhOdA9Z1LtPSXeO714qZW9wT27O7KOWr3gFqI9PrxtvG0bnz0Orfy96iIMvdrbCbyyESA9PX3iPObIuj0UXJS6hKX9O7iKojzjkYK9j7RCO/8zCTswIiI9K6S+PdU/w71hUOs8/xxEvZZVvz1krfQ9Nb5RvT+vO70ZVvO93zzJPX+xjD16HzE8BOgBvkOR1L3gk5C9rdKiPS//Trzh9bu9cg/XvTxvkDu70XG9mea5vYVjkr276rk9PIV3vefFhD2NWLg9nM1GvFkDgT1Yv4S9TG2lvWRG+D1T3wE96ewHPibwij2DXLw6MriXvTMuFT5YcDy9LCkuPY/lCb2OQcs9KVeCvaAI273epJk8HDLuvOyfmz3PrXG98DV0PAvkErys4ya8rIDhvEFoEz180i49by+jvbUN8L3Cfzs9AMb4Pda4yzxkNaE9xZCqvU5WnT2qhoG9nlv5vcGwvb169Za9/o2YvbMGXb0gYIa7CoyePT3N5Tu7N0W9QBbovMtmyT3Acec8icfxvVDkBLxRvWe9QRAAvu0ncD2nG4q9d07DPUKA4Twk66k9gIIBvZ6qsr29G5Q7qFbYvczAvL36iQg8mzYqPGMYwr1Nd1c97ZFevbFYer2YJF09aFHePR+ggDxJkce9wrmqPZZ3rD1105U90JmlPQnABL7RIkK9jj0ZPHoSkz01XbW7Vbq3vecIUT1/RUy9KmDEPdDqqj0xz0A93YmGvPBeSbwuDKI8CBqBPZRtuD32nNq9ISP4veBNT73ZagK++WS7vQOO/73bxUi9Wx2jPfq1rz1AHem7sm75PR9+nb3bgmQ9jgjMvfgqqL3AgXe9/ewHvjpWqr0wNzW9tonXPeOXp72cXPI8+KZ/PUktST3Pkq68xJBSvKFGXr2TK6w7OvwQPReTX73pQ8+9zfHLvE62Vbz0DGm9Z3ImPThBeb203os9NtMAPrxmB74G0iQ97oQ8PSjCqz2Rez89GNwRPdSP9T1uKNa9EbQAvghH0LynnAe6oQCTPR+J3D1YLAm8tJp9va3foD2lmsI9TFgTPYgHlTtQssU90GOVvXwHSD3mgNw9eExOPbCwoj2mKVo9DO+rPaMMhD0O8Ig9EkhfPM/Awb2J7c09sicfPXSc37zA+qk9IWq7PVidxLzec7s9Jv4cPVRAJ73av9I9ycO9Pcbrtr0+sKy9fktOvQ1bzL1Br+c80ZArvuox8ryrQ9C791PfPPGXKrzvixE+06anPczd8L0npiS+KPiKvHo4bb1/c6y9AL3iPOkSAL5iwrq9fKWIPWRtpD0lUQQ+W6OPvRk1pb0w2NY9wiecPMmYZD2oRa694YrLvGA7Cr1OUfY9X2Gxvb5wQL2Bzqo9Gf2TvXn5+T3RJac9GntBvSIiVTpwcL09NC2+Pfuiv713cM+7qMbpPYrdCT3e+RY9swVNPa2M1r2z4Oc99tXhvQnsXjxhsXy7abPZPcF23TxpzZo8aF0vPcVjqj2f98+8EJUxPT1i/T0YtcU94I/5PBX2Kj2zYo49GLvkPdcJ3L0F58E9AIStvShVeD2VD7w9+a7avYD2vb2+H9Q9X3ZQPQH2kz3GFWO981K2vXwzhb3ZeFS9nO11PH5Znb2FPVK8UbSyveR8yT257g89RIK8vR7vqj0k+Cc+PJ+2PTWhlD0aWvK9iot+vSR3tj23Jbq9sBeqvMEQh73LxrU83NjDPQBHJDuTsJS9incRO0SB8j1r4wG9bcrvvHQ6uL1LUkC97XFaPD9BgD1cn8i8fAfKPJJGz731vp89iBrHPeSH2r3cHHS9BkAnPJn+x71D6DM90D25vSDZ/L031WG9wQlPPZ7mmT0TIGw9iCCKPbxD4L1ZBGc7VlJ3veuf2D3iEmy8ZOKNvWhro723Tms9Eg6HvfMAwzyh2ZM5nHBQutM3SD3N/2W98HNkPWsQtz2Prao9TRPxvaChrT3AeL28iGDUPWhxub0F9cS9jqQLvrfRlj0axp898Zm9PeGFij38zuW9OMxjOxe0l73xKZ09GrcOvpA/mL3f6ue8SG60vZtnnrxEKck8k6y2vU3iNb2M6YM8/IhnvftA17zCrZk9URPxPAX4mr2Edf68h99NPTMrjD1sV9M9G8rMPTn4tz20hWQ9FaJ9vQP7qrw70KQ8yXHePbJl0D0Aq2y9U4KkvB2XxD3xLZE96BsAvgAAFz04M3U9O1ZjvAZO3D0YwhY93cAEPul4fT3BDOm9sg/Mvd2JOr1Uwp49EQOyPVii7z0qnTc9YdZqPaPEmjvKjJc9W5GlvN1U37zLOeA9YH6UO4ut2j0PbmQ93gKhvTs+0j17WJ89yxnHPcHXN7w/+NS9Z0H0vSU10D2PAu09ixiqPCIOsTtYi5i8h/8WOxND4D01Zu88DmohPVpxOT2iaXK8iF2XO3mcnTzpXeq9pP+ovWfKtjzLmEg8H5p/PHSnNz0F6Yc9wt8Bvl7UVD02Lfq9XVy4vT+tkb2HoWW9XfX3vZmZ4r0I99C93HZkPZ4gFLoeSD+9n5zUOx1SDr0caB89fjPWvYlBzbyd+8q886uHvL+KAj7SZAG+lHSUYowCYjKUaAJoBUsAhZRoB4eUUpQoSwFLIIWUaBqJQ4DSzLU9HMjLPa7mU7y88z29qpbLvaf1hrw2BGC9wYcHvlcphTzoX8M9+bfTPXZLsr2agZS8fq0APgti1T1tVHs914FwvFePmj23zmw9LWSwPfeCeD25ntQ9oGUgvUZ8vr2BJKI8Yn+BvCMtAL745+c8R8VrvS0SQj2X+i69Czm9vJR0lGKMAlczlGgCaAVLAIWUaAeHlFKUKEsBSwFLIIaUaBqJQ4AncTM+N0IDvtdgor1saPa91u2SvKzFBj753PM9cSUjvhgT4Lu1VgI+uJ6jvDoH2T06Dum9lHnjPa6Z3jq75yE82toOvq0MMr3fsBm+VDmsvO5loT11ODG9Cjw1vbagi720Mv89XpsIPsAmi70vcwW+432jPXDHg70Z/Bq+GQGEvZR0lGKMAmIzlGgCaAVLAIWUaAeHlFKUKEsBSwGFlGgaiUMEYaySO5R0lGJ1YXSUYi4="  # left empty: NeuralVal will use random init (still safe as a small modifier).


def target_score(snap: Snapshot, src: Planet, dst: Planet) -> Tuple[float, int, int]:
    """Score (score, need, eta) — v20: distance-dominant scoring (v19 lineage).

    核心原则（模仿 top 方案）：
    - 近处目标天然占优（eta 是强惩罚因子）
    - 高产值星球有额外加成
    - 路径穿越太阳的目标直接判死（不调 safe_aim，纯几何检查）
    - 不跨越太阳去打远处目标
    """
    state = snap.state
    if dst.owner == state.my_id or src.id == dst.id:
        return -1e18, 0, 0

    need, eta = capture_need(state, src, dst)
    if need <= 0:
        return -1e18, 0, eta

    # 球心连线擦过太阳：启发式上偏难，但弹道可从边缘绕行（见 _emit / safe_aim）。
    # 旧逻辑直接 -1e18 使内环球长期进不了排序；改为扣分，交给真轨迹门。
    sun_detour_pen = 0.0
    sun_dist = point_segment_distance(SUN_X, SUN_Y, src.x, src.y, dst.x, dst.y)
    if sun_dist < SUN_RADIUS + SUN_PATH_MARGIN:
        sun_detour_pen = 42.0 + eta * 0.30

    raw_turns = max(1, state.turns_left() - eta)
    turns = min(raw_turns, HORIZON_TURNS)
    if dst.is_comet:
        turns = min(turns, max(0, state.comet_turns_left(dst) - eta), 60)
        if turns <= 8:
            return -1e18, need, eta

    is_neu = dst.owner == -1
    is_en = dst.owner not in (-1, state.my_id)

    # Snipe-aware sizing for neutrals
    if is_neu and dst.production > 0 and dst.ships > dst.production:
        e_eta_first, _ = enemy_eta_power(state, dst)
        if 0 < e_eta_first < eta:
            owner_after, ships_after = target_state_at(state, dst, e_eta_first + 1)
            if owner_after not in (-1, state.my_id):
                snipe_eta = max(eta, e_eta_first + 1)
                snipe_need = ships_after + 8 + min(6, dst.production)
                snipe_need += dst.production * snipe_eta // 5
                if snipe_need > need:
                    need = max(need, snipe_need)
                    eta = snipe_eta

    # === 打分（distance-dominant） ===

    # 产值回报：占据后每回合收益 × 收益轮数，但用 min(turns, 30) 压缩远期
    prod_value = dst.production * min(turns, 30)

    # 高产加成：prod>=5 的星球是战略目标
    prod_bonus = 0.0
    if dst.production >= 5:
        prod_bonus = 40.0 + dst.production * 5.0
    elif dst.production >= 3:
        prod_bonus = 15.0 + dst.production * 3.0
    elif dst.production >= 1:
        prod_bonus = dst.production * 2.0

    # 敌方星球额外价值（夺取=削弱对手+增强自己）；贴身弱敌强推（expand 曾漏掉 >20 驻军的邻球）
    enemy_bonus = 30.0 if is_en else 0.0
    if is_en and src.dist(dst) < 20.0:
        enemy_bonus += 35.0
    comet_bonus = 12.0 if dst.is_comet else 0.0
    rec_bonus = recapture_bonus(snap, dst)
    # Early race for big factories: nudge expand ordering toward prod>=4 neutrals.
    early_hot_neutral = (
        22.0 if (is_neu and state.phase() == "early" and dst.production >= 4) else 0.0
    )
    # Value-per-commitment: prod^2 / need  favors factories over low-prod mites when
    # distances are similar (common case: 20@prod4 vs 14@prod1).
    neutral_mfg = 0.0
    if is_neu:
        neutral_mfg = 48.0 * float(dst.production * dst.production) / max(1.0, float(need))

    # 距离惩罚：eta 的 **强** 衰减——这是与旧版最大的区别
    # eta=5 → 0.67, eta=10 → 0.50, eta=20 → 0.37, eta=30 → 0.31
    distance_decay = 1.0 / (1.0 + eta * 0.10)

    # 兵力成本：需要的兵越多，性价比越低
    cost_pen = 0.0
    if eta > 3:
        cost_mul = snap.policy.cost_pen_neutral_mul if is_neu else snap.policy.cost_pen_mul
        cost_pen = cost_mul * need

    # Sniping risk
    snipe_pen = 0.0
    if is_neu:
        e_eta, e_pow = enemy_eta_power(state, dst)
        if e_eta <= eta + 1 and e_pow > max(0, need - 4):
            snipe_pen = 30.0
        elif e_eta <= eta + 2 and e_pow > need + 5:
            snipe_pen = 15.0

    # 1 产「蚊子球」：前期主动压低排序，避免和轨道上 3–4 产厂星抢优先（用户反馈先占 14@1 再等 20@4）。
    mite_neutral_pen = 0.0
    if is_neu and state.phase() == "early" and dst.production <= 1:
        mite_neutral_pen = 38.0

    orbit_arc = 0.0
    approach_adj = 0.0
    fat_local_neu = 0.0
    finish_neu = 0.0
    if is_neu:
        if state.en_pl:
            orbit_arc = orbit_arc_strategic_score(state, dst, eta)
            approach_adj = 0.48 * approach_bonus(snap, dst, eta)
        if dst.ships >= 38:
            d_anchor = min(dst.dist(m) for m in state.my_pl)
            if d_anchor < 36.0:
                # 身边大灰（如 59）：优先吃近处高驻军工厂，少去追「路过」小灰
                fat_local_neu = 16.0 + (36.0 - d_anchor) * 1.65 + min(22.0, dst.ships * 0.08)
        oth = my_inbound_ships_to(state, dst.id)
        if oth > 0 and oth <= dst.ships + 4:
            # 已有己方舰队在途但未够占领：优先补刀，避免下回合改打远处浪费产兵
            gap = (dst.ships + 1) - oth
            if 1 <= gap <= 18:
                finish_neu = 52.0 + (18 - gap) * 1.5

    score = (
        prod_value + prod_bonus + enemy_bonus + comet_bonus + rec_bonus
        + early_hot_neutral + neutral_mfg + fat_local_neu + finish_neu
        + orbit_arc + approach_adj
    ) * distance_decay
    score -= cost_pen + snipe_pen + mite_neutral_pen + sun_detour_pen
    # 内环球中立：战略优先级（旋转进对手弧前须占）
    if is_neu and is_sun_belt_planet(state, dst):
        score += 38.0 * distance_decay
    return score, need, eta


def regional_capture_adjustment(
    snap: Snapshot,
    src: Planet,
    dst: Planet,
    regional_graph: RegionalGraph,
    eta: int,
) -> float:
    """Additive regional layer: cohesion bonus or cross-zone expedition tax."""
    state = snap.state
    my_ids = {p.id for p in state.my_pl}
    rid_s = regional_graph.planet_to_region.get(src.id, -1)
    rid_d = regional_graph.planet_to_region.get(dst.id, -1)
    if rid_s < 0 or rid_d < 0:
        return 0.0

    ddist, _ = regional_graph.dijkstra(src.id, dst.id)
    dist_cost = 0.12 * min(ddist, 80.0)

    if rid_s == rid_d:
        my_prod = regional_graph.region_production(rid_d, my_ids)
        bonus = 8.0 + min(22.0, float(my_prod) * 1.55)
        pot = 0.0
        for p in regional_graph.get_planets_in_region(rid_d):
            if p.id == dst.id:
                continue
            if p.owner == -1:
                pot += float(p.production) + 0.5
            elif p.owner in state.en_ids:
                eg = state.effective_garrison(p)
                if eg < p.ships * 0.65:
                    pot += float(p.production) * 0.6
        bonus += min(16.0, pot * 1.8)
        return bonus - dist_cost * 0.35

    cross = 10.0 + 0.045 * float(eta * eta)
    if is_sun_belt_planet(state, dst) and dst.owner == -1:
        cross *= 0.38
    return -cross - dist_cost


registry.target_score = target_score
registry.regional_capture_adjustment = regional_capture_adjustment
registry.neural_weights_b64 = _NEURAL_WEIGHTS_B64
registry.arbiter_variant = "v20"

from orbit_submit.engine import DiplomacyEngine, OpponentModel, PlanArbiter
from orbit_submit.neural import NeuralVal
from orbit_submit.policy import PhasePolicy
from orbit_submit.regional import MultiHopPlanner, ProductionTimeline, RegionalGraph as _RG

_GLOBAL_OPP = OpponentModel()
_GLOBAL_NEURAL = NeuralVal()


def agent(obs, config=None):
    """Kaggle-required entry. Returns list of [src_id, angle, ships] moves."""
    global _GLOBAL_OPP, _GLOBAL_NEURAL
    t0 = time.time()
    elapsed = lambda: (time.time() - t0) * 1000.0

    try:
        state = GameState(obs, config, ruleset="v20")
        if not state.my_pl:
            return []

        _GLOBAL_OPP.update(state)
        policy = PhasePolicy.for_state(state)
        snap = Snapshot.build(state, policy)
        diplo = DiplomacyEngine(state, _GLOBAL_OPP)

        regional_graph = None
        multi_hop_planner = None
        try:
            spawn_positions = config.get("spawn_positions", []) if config else []
            regional_graph = _RG(state.planets, spawn_positions)
            timeline = ProductionTimeline(state.planets, set(p.id for p in state.my_pl))
            multi_hop_planner = MultiHopPlanner(regional_graph, timeline)
        except Exception:
            regional_graph = None
            multi_hop_planner = None

        arbiter = PlanArbiter(
            snap,
            diplo,
            _GLOBAL_NEURAL,
            elapsed_ms_fn=elapsed,
            deadline_ms=920.0,
            regional_graph=regional_graph,
            multi_hop_planner=multi_hop_planner,
        )

        arbiter.commit_urgent()
        plans = arbiter.collect_strategic()
        scored = arbiter.score_with_modifiers(plans)
        arbiter.commit_best(scored)
        arbiter.commit_fallback()

        return arbiter.moves
    except Exception:
        return []
